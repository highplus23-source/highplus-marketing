// netlify/functions/billing-success.js
exports.handler = async (event) => {
  const { authKey, customerKey, orderId, productId, uid } = event.queryStringParameters || {};
  if (!authKey || !customerKey) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body: '<html><body><h2>\uBE4C\uB9C1 \uC778\uC99D \uC815\uBCF4\uAC00 \uC62C\uBC14\uB974\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.</h2><a href="/">\uD648\uC73C\uB85C \uB3CC\uC544\uAC00\uAE30</a></body></html>'
    };
  }
  const secretKey = process.env.TOSS_SECRET_KEY;
  const encryptedKey = Buffer.from(secretKey + ":").toString("base64");
  try {
    const billingResponse = await fetch("https://api.tosspayments.com/v1/billing/authorizations/issue", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${encryptedKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ authKey, customerKey })
    });
    const billingResult = await billingResponse.json();
    if (!billingResponse.ok) {
      console.error("\uBE4C\uB9C1\uD0A4 \uBC1C\uAE09 \uC2E4\uD328:", billingResult);
      return {
        statusCode: 302,
        headers: {
          "Location": `/payment-fail.html?code=${billingResult.code}&message=${encodeURIComponent(billingResult.message)}`
        }
      };
    }
    const billingKey = billingResult.billingKey;
    const paymentOrderId = orderId || `HP-SUB-${Date.now()}`;
    const amount = 275e3;
    const payResponse = await fetch(`https://api.tosspayments.com/v1/billing/${billingKey}`, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${encryptedKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        customerKey,
        amount,
        orderId: paymentOrderId,
        orderName: "Ai\uC2E4\uC7A5 \uC6D4 \uAD6C\uB3C5 (\uCCAB \uB2EC)",
        customerEmail: "",
        taxFreeAmount: 0
      })
    });
    const payResult = await payResponse.json();
    if (payResponse.ok) {
      console.log("\uAD6C\uB3C5 \uACB0\uC81C \uC131\uACF5:", {
        uid,
        billingKey,
        orderId: paymentOrderId,
        amount,
        subscribedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      return {
        statusCode: 302,
        headers: {
          "Location": `/payment-success.html?orderId=${paymentOrderId}&amount=${amount}&type=subscription`
        }
      };
    } else {
      console.error("\uCCAB \uB2EC \uACB0\uC81C \uC2E4\uD328:", payResult);
      return {
        statusCode: 302,
        headers: {
          "Location": `/payment-fail.html?code=${payResult.code}&message=${encodeURIComponent(payResult.message)}`
        }
      };
    }
  } catch (error) {
    console.error("\uC11C\uBC84 \uC624\uB958:", error);
    return {
      statusCode: 302,
      headers: {
        "Location": `/payment-fail.html?code=SERVER_ERROR&message=${encodeURIComponent("\uC11C\uBC84 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.")}`
      }
    };
  }
};
