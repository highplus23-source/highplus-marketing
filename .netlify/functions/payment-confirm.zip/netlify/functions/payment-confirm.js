// netlify/functions/payment-confirm.js
exports.handler = async (event) => {
  const { paymentKey, orderId, amount } = event.queryStringParameters || {};
  if (!paymentKey || !orderId || !amount) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body: '<html><body><h2>\uACB0\uC81C \uC815\uBCF4\uAC00 \uC62C\uBC14\uB974\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.</h2><a href="/">\uD648\uC73C\uB85C \uB3CC\uC544\uAC00\uAE30</a></body></html>'
    };
  }
  const secretKey = process.env.TOSS_SECRET_KEY;
  const encryptedKey = Buffer.from(secretKey + ":").toString("base64");
  try {
    const response = await fetch("https://api.tosspayments.com/v1/payments/confirm", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${encryptedKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ paymentKey, orderId, amount: Number(amount) })
    });
    const result = await response.json();
    if (response.ok) {
      return {
        statusCode: 302,
        headers: {
          "Location": `/payment-success.html?orderId=${orderId}&amount=${amount}&method=${encodeURIComponent(result.method || "\uCE74\uB4DC")}`
        }
      };
    } else {
      console.error("\uACB0\uC81C \uC2B9\uC778 \uC2E4\uD328:", result);
      return {
        statusCode: 302,
        headers: {
          "Location": `/payment-fail.html?code=${result.code}&message=${encodeURIComponent(result.message)}`
        }
      };
    }
  } catch (error) {
    console.error("\uC11C\uBC84 \uC624\uB958:", error);
    return {
      statusCode: 302,
      headers: {
        "Location": `/payment-fail.html?code=SERVER_ERROR&message=${encodeURIComponent("\uC11C\uBC84 \uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.")}`
      }
    };
  }
};
